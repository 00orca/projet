var searchData=
[
  ['loadimage',['loadImage',['../interface_8c.html#a89ec9714714171f543937996e182f06e',1,'loadImage(image_t image[Z], SDL_Renderer *renderer):&#160;interface.c'],['../interface_8h.html#a89ec9714714171f543937996e182f06e',1,'loadImage(image_t image[Z], SDL_Renderer *renderer):&#160;interface.c']]]
];
