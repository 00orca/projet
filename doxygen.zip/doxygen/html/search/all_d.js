var searchData=
[
  ['update_5fgrille',['update_grille',['../grille_8c.html#a1fab75e42ccb5bf0c14b7b9bdac37cf9',1,'update_grille(case_t terrain[N][M], int compteur_tour, bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;grille.c'],['../grille_8h.html#a1fab75e42ccb5bf0c14b7b9bdac37cf9',1,'update_grille(case_t terrain[N][M], int compteur_tour, bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;grille.c']]],
  ['update_5fstats',['update_stats',['../combat_8c.html#ac81be82a4a2618ac7509013d0ab264d8',1,'update_stats(case_t terrain[N][M], int x, int y, int joueur_actu, joueurs_t tab[J]):&#160;combat.c'],['../combat_8h.html#ac81be82a4a2618ac7509013d0ab264d8',1,'update_stats(case_t terrain[N][M], int x, int y, int joueur_actu, joueurs_t tab[J]):&#160;combat.c']]]
];
