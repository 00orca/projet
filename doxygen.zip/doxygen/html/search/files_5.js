var searchData=
[
  ['logs_2ec',['logs.c',['../logs_8c.html',1,'']]],
  ['logs_2eh',['logs.h',['../logs_8h.html',1,'']]]
];
