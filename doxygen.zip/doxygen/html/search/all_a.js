var searchData=
[
  ['reste_5fallie',['reste_allie',['../grille_8c.html#ad846900e8f5d71a36268cf3ab7ece35f',1,'reste_allie(case_t terrain[N][M], int joueur_actu):&#160;grille.c'],['../grille_8h.html#ad846900e8f5d71a36268cf3ab7ece35f',1,'reste_allie(case_t terrain[N][M], int joueur_actu):&#160;grille.c']]],
  ['reste_5fennemi',['reste_ennemi',['../grille_8c.html#af9ae509327ec36c8c85dde2ea05345ac',1,'reste_ennemi(case_t terrain[N][M], int joueur_actu):&#160;grille.c'],['../grille_8h.html#af9ae509327ec36c8c85dde2ea05345ac',1,'reste_ennemi(case_t terrain[N][M], int joueur_actu):&#160;grille.c']]]
];
