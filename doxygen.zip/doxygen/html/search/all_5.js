var searchData=
[
  ['ia_5fblockage_5fdirection',['IA_blockage_direction',['../bot_8c.html#aae5f6c62fb0941e936c013966f55ca23',1,'IA_blockage_direction(case_t terrain[N][M], int x_def, int y_def, int joueur_actu):&#160;bot.c'],['../bot_8h.html#aae5f6c62fb0941e936c013966f55ca23',1,'IA_blockage_direction(case_t terrain[N][M], int x_def, int y_def, int joueur_actu):&#160;bot.c']]],
  ['image_5fs',['image_s',['../structimage__s.html',1,'']]],
  ['init_5fpiece',['init_piece',['../piece_8h.html#ac853106a2a9445258cba7ba03dc6eec0',1,'piece.c']]],
  ['initialisation_5fprincipale',['initialisation_principale',['../grille_8c.html#a0f42ea692bc19acc03caa507bea4b7fa',1,'initialisation_principale(int bordure, SDL_Window *pWindow, int *largeur, int *hauteur, joueurs_t tab[J], degatx_t aff_deg[AFF_DEG], bash_t tab_info_bash[TAILLE_TAB_BASH], case_t terrain[N][M], char variable2[80]):&#160;grille.c'],['../grille_8h.html#a0f42ea692bc19acc03caa507bea4b7fa',1,'initialisation_principale(int bordure, SDL_Window *pWindow, int *largeur, int *hauteur, joueurs_t tab[J], degatx_t aff_deg[AFF_DEG], bash_t tab_info_bash[TAILLE_TAB_BASH], case_t terrain[N][M], char variable2[80]):&#160;grille.c']]],
  ['interface_2ec',['interface.c',['../interface_8c.html',1,'']]],
  ['interface_2eh',['interface.h',['../interface_8h.html',1,'']]]
];
