var searchData=
[
  ['degatx_5fs',['degatx_s',['../structdegatx__s.html',1,'']]]
];
