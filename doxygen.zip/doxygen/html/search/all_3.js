var searchData=
[
  ['degatx_5fs',['degatx_s',['../structdegatx__s.html',1,'']]],
  ['depla_5fallie_5fplus_5fproche',['depla_allie_plus_proche',['../bot_8c.html#a8e34a70c79d87a5314ce74e2ef408e16',1,'depla_allie_plus_proche(case_t terrain[N][M], int x_bot, int y_bot, int joueur_actu, joueurs_t tab[J], bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;bot.c'],['../bot_8h.html#a8e34a70c79d87a5314ce74e2ef408e16',1,'depla_allie_plus_proche(case_t terrain[N][M], int x_bot, int y_bot, int joueur_actu, joueurs_t tab[J], bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;bot.c']]],
  ['depla_5fatk_5fmov',['depla_atk_mov',['../bot_8c.html#add1ef78fa564c42ce9f994c16b98d590',1,'depla_atk_mov(case_t terrain[N][M], int x_bot, int y_bot, int joueur_actu, joueurs_t tab[J], bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;bot.c'],['../bot_8h.html#add1ef78fa564c42ce9f994c16b98d590',1,'depla_atk_mov(case_t terrain[N][M], int x_bot, int y_bot, int joueur_actu, joueurs_t tab[J], bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;bot.c']]],
  ['depla_5fennem_5fplus_5fproche',['depla_ennem_plus_proche',['../bot_8c.html#a2c5629a929c67a14a0f10bc58958d8cd',1,'depla_ennem_plus_proche(case_t terrain[N][M], int x_bot, int y_bot, int joueur_actu, joueurs_t tab[J], bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;bot.c'],['../bot_8h.html#a2c5629a929c67a14a0f10bc58958d8cd',1,'depla_ennem_plus_proche(case_t terrain[N][M], int x_bot, int y_bot, int joueur_actu, joueurs_t tab[J], bash_t tab_info_bash[TAILLE_TAB_BASH], char variable2[80]):&#160;bot.c']]],
  ['deplacement_2ec',['deplacement.c',['../deplacement_8c.html',1,'']]],
  ['deplacement_2eh',['deplacement.h',['../deplacement_8h.html',1,'']]],
  ['destruction_5fpiece',['destruction_piece',['../piece_8h.html#acb1e1bf34b72b8071edef596983d2239',1,'piece.c']]]
];
