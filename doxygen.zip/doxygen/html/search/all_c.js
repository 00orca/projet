var searchData=
[
  ['tactics_20arena',['Tactics Arena',['../index.html',1,'']]]
];
