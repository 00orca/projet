var searchData=
[
  ['case_5fs',['case_s',['../structcase__s.html',1,'']]]
];
