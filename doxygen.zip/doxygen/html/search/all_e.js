var searchData=
[
  ['vide',['vide',['../logs_8c.html#a769e0f37f5bd0866837eac0f77d2ae13',1,'vide(degatx_t aff_deg[AFF_DEG]):&#160;logs.c'],['../logs_8h.html#a769e0f37f5bd0866837eac0f77d2ae13',1,'vide(degatx_t aff_deg[AFF_DEG]):&#160;logs.c']]]
];
